from cgi import print_form
from enum import auto
import os
from tkinter import Button
from flask import Flask, render_template, request, url_for
from flask_dropzone import Dropzone

import urllib.request
import os
import zipfile
import tensorflow as tf
import keras.api._v2.keras as keras
from keras.optimizers import RMSprop
from keras.preprocessing.image import ImageDataGenerator
from keras.preprocessing import image
import numpy as np
from PIL import Image


basedir = os.path.abspath(os.path.dirname(__file__))

app=Flask(__name__)

app.config.update(
    UPLOADED_PATH= os.path.join(basedir,'uploads'))

dropzone = Dropzone(app)
app.config['DROPZONE_MAX_FILE_SIZE']=7

cache=[]

@app.route('/',methods=['POST','GET'])
def index():
    if request.method == 'POST':
        f = request.files.get('file')
        f.save(os.path.join(app.config['UPLOADED_PATH'],"imagen.jpg"))
        if len(cache)==0:
            cache.append(f)
        else:
            cache[0]=f

    return render_template('index.html')

@app.route('/clasificador',methods=['POST','GET'])
def clasificador():
    if request.method == 'POST':
        if request.form['boton_clasificar'] == 'Clasificar imagenes':
            mensaje=modeloRed()
            return render_template('index.html',mensaje_predict=mensaje)

def modeloRed():
    #Definicion del modelo
    model = tf.keras.models.Sequential([
        # tf.keras.layers.Conv2D(filtros, tamaño_kernel, activacion, input_shape)
        # input_size es la forma deseada de la imagen (150x150) con 3 bytes de color
        # Bloque de convolución 1
        tf.keras.layers.Conv2D(80, (3,3), activation='relu', input_shape=(150, 150, 3)),
        tf.keras.layers.MaxPooling2D(2,2),
        
        # Bloque de convolución 2
        tf.keras.layers.Conv2D(100, (3,3), activation='relu'),
        tf.keras.layers.MaxPooling2D(2,2), 
        
        # Bloque de convolución 3
        tf.keras.layers.Conv2D(100, (3,3), activation='relu'),
        tf.keras.layers.Conv2D(100, (3,3), activation='relu'), 
        tf.keras.layers.MaxPooling2D(2,2),
        
        #Dropout
        tf.keras.layers.Dropout(0.25),
        
        # "Aplana" los resultados para pasárselos a una DNN (Deep neural network)
        tf.keras.layers.Flatten(), 
        
        # Neuronas de capa oculta: 512
        tf.keras.layers.Dense(256, activation='relu'),
        tf.keras.layers.Dense(32, activation='relu'),
        
        # Neurona de salida que devuelve dos valores: 0 para gallinas muertas y 1 para gallinas vivas.
        tf.keras.layers.Dense(1, activation='sigmoid')  
    ])

    #Compilar el modelo
    model.compile(optimizer=RMSprop(learning_rate=0.001),loss='binary_crossentropy',metrics = ['accuracy'])

    #Clasificar la imagen
    path="C:\\Users\\Saul\\VisualStudioCode\\Webapp_TFG\\uploads\\imagen.jpg"
    img=image.image_utils.load_img(path, target_size=(150, 150))

    x=image.image_utils.img_to_array(img)
    x=np.expand_dims(x, axis=0)
    images = np.vstack([x])
  
    classes = model.predict(images)
  
    if classes[0]>0.3:
        mensajeFinal="No hay aves muertas en esta jaula"
    else:
        mensajeFinal="Hay algún ave muerta en esta jaula"

    return mensajeFinal


if __name__ == "__main__":
    app.run(debug=False)